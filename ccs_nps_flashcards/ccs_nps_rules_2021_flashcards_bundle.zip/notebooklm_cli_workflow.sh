#!/usr/bin/env bash
# SKILL.md-compliant ID-pinned Gemini NotebookLM CLI workflow for local workstation execution
# Prerequisite: `notebooklm login` and `notebooklm auth check --test --json` -> .status == "ok"
set -euo pipefail

NB_JSON=$(notebooklm create "CCS (Implementation of NPS) Rules, 2021 & Latest 2026 Updates" --json)
NB_ID=$(printf '%s' "$NB_JSON" | python3 -c 'import json,sys; print(json.load(sys.stdin)["notebook"]["id"])')
echo "Created Notebook ID: $NB_ID"

SRC_JSON=$(notebooklm source add "https://cpao.nic.in/pdf/NPS_ENGLISH_BOOK.pdf" -n "$NB_ID" --json)
SRC_ID=$(printf '%s' "$SRC_JSON" | python3 -c 'import json,sys; print(json.load(sys.stdin)["source"]["id"])')
notebooklm source wait "$SRC_ID" -n "$NB_ID" --timeout 600

TASK_JSON=$(notebooklm generate flashcards \
  "Exam-oriented flashcards covering every Rule (1-30), sub-rule, clause, sub-clause, proviso, explanation, exception, and Form (1 to 4-E) of CCS (Implementation of NPS) Rules, 2021" \
  --quantity more --difficulty hard -n "$NB_ID" -s "$SRC_ID" --json)
ART_ID=$(printf '%s' "$TASK_JSON" | python3 -c 'import json,sys; print(json.load(sys.stdin)["task_id"])')

notebooklm artifact wait "$ART_ID" -n "$NB_ID" --timeout 1200
notebooklm download flashcards ./ccs_nps_flashcards_live.md -a "$ART_ID" -n "$NB_ID"
notebooklm download flashcards ./ccs_nps_flashcards_live.html -a "$ART_ID" -n "$NB_ID"
